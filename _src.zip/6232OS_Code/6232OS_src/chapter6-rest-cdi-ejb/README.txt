Deploy to wildfly by any of the management interfaces, and go to this URL:
http://localhost:8080/packtpub/logging/example