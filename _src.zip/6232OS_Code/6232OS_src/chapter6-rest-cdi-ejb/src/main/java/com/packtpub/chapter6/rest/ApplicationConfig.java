package com.packtpub.chapter6.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("packtpub")
public class ApplicationConfig extends Application { }
